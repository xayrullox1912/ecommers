class Product:

    def __init__(self, name, stock, price, category):
        self.name = name
        self.stock = stock
        self.price = price
        self.category = category
    
    
