class Orders:

    def __init__(self, product, total, username, state):
        self.product = product
        self.total = total
        self.username = username
        self.state = state # buyurtma berildi, qabul qilindi
        

    
